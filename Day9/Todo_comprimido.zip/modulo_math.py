import math 
# redondear hacia abajo
resultado = math.floor(89.665)
print(resultado)
# redondear hacia arriba
resultado = math.ceil(89.665)
print(resultado)
# pi
resultado = math.pi
print(resultado)
# trigonometria
resultado = math.log(25, 5)
print(resultado)
# tangente
resultado = math.tan(2565)
print(resultado)
# coseno
resultado = math.cos(2565)
print(resultado)
# factoria
resultado = math.factorial(7)
print(resultado) 